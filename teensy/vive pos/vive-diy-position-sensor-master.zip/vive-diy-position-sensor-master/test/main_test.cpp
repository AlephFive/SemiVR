#define CATCH_CONFIG_MAIN
#include <catch.hpp>

// Main Catch.hpp file. Don't place anything here.
